import { Link } from "react-router-dom";
const About = () => {
  return (
    <div>
      <h4>Versão 2</h4>
      <h5>BIA DEBUG-ENV</h5>
      <Link to="/">Voltar</Link>
    </div>
  );
};

export default About;
